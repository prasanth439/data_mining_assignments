//// Files Explanation ///
fptree.cpp fptree.h   -  for fptree algorithm
apriori.cpp 		  -  for aprior algorithm
compile.sh and rollnumber.sh - as per submission guidelines

//// Part 2 Plot Explanation ///


Since we are not loading the total transactions into memory for the apriori algorithm
we need to scan the file once for every candidate to frequency set conversion. So we need to 
parse lines every time while scanning file which is overhead compared to fp tree. And fp tree  compressess and represents data in compact manner. So time taken by fptree for any support threshold is
always less than apriori algorithm.



//// Team Members ///
Prasanth     2016CS10358
Anirudh      2016CS10362
SaurabhJain  2019ANZ8278

#/bin/bash
time_file1="time_file1.txt"
time_file2="time_file2.txt"
apriEXE="apriori"
fpTREE="fptree"
folder=$1
timelimit=1800
if [[ $1 = "-plot" ]]; then
    folder=$2
    for number in 1 5 10 25 50 90
    do
        # ./$fpTREE $number $folder $filename $time_file1 
        timeout $timelimit ./$fpTREE $number $folder $time_file1 0
        status=$?
        if [ $status != 0 ]; then
            echo $timelimit >> $time_file1 
        fi
    done
    for number in 1 5 10 25 50 90
    do
        # ./$apriEXE $number $folder $filename $time_file2 
        timeout $timelimit ./$apriEXE $number $folder $time_file2 0
        status=$?
        if [ $status != 0 ]; then
            echo $timelimit >> $time_file2
        fi
    done
    python3 plot.py $folder
elif [[ $3 = "-apriori" ]]; then
    filename=$4 
    # ./$apriEXE $number $folder $filename 
    timeout $timelimit ./$apriEXE $2 $folder "$filename.txt" 1
  
else 
    filename=$4
    # ./$fpTREE $number $folder $filename $output
    timeout $timelimit ./$fpTREE $2 $folder "$filename.txt" 1   
fi

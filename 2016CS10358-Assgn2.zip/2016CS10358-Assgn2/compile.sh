cd gBolt
g++ -O3 -o gbolt src/* -Iinclude/ -w
cd ..
make
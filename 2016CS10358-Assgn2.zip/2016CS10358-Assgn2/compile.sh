cd gbolt
./delete.sh
cd ..
make
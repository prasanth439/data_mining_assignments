

python plot.py $1 $2
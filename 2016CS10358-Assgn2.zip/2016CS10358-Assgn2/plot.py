import sys
import os
from timeit import timeit
from matplotlib import pyplot as plt

inputFileName=sys.argv[1]
outFileName = sys.argv[2]
supports=[90]
gspan=[]
fsg=[]
gaston=[]
# Convert files here

converted_file_gsp = inputFileName + "gsp"
converted_file_fsg = inputFileName + "fsg"
converted_file_gaston = inputFileName + "gaston"
#converted_file_gsp = "Chemical_340"
#converted_file_fsg = "Chemical_340_fsg"
#converted_file_gaston = "Chemical_340"

timeit(stmt="os.system('./gspc {} {}')".format(inputFileName,converted_file_gsp ), setup="import os", number=1)
timeit(stmt="os.system('./fsgc {} {}')".format(inputFileName,converted_file_fsg ), setup="import os", number=1)
timeit(stmt="os.system('./gastonc {} {}')".format(inputFileName,converted_file_gaston ), setup="import os", number=1)

for thresh in supports:
  gspan.append(timeit(stmt="os.system('./gSpan-64 -f {} -s {} -o')".format(
    converted_file_gsp, thresh/100), setup="import os", number=1))
  fsg.append(timeit(stmt="os.system('./fsg -s {} {}')".format(
    thresh,converted_file_fsg), setup="import os", number=1))
  gaston.append(timeit(stmt="os.system('./gaston {} {} output{} ')".format(
      thresh, converted_file_gaston,thresh), setup="import os", number=1))

plt.plot(supports, gspan, label='gspan',c='b')
plt.plot(supports, fsg, label='fsg',c='g')
plt.plot(supports, gaston, label='gaston',c='y')
plt.title('Running Time Vs Support threshold')
plt.xlabel('Support threshold(%)')
plt.ylabel('Time taken(s)')
plt.legend(loc='upper right')
plt.savefig(outFileName)

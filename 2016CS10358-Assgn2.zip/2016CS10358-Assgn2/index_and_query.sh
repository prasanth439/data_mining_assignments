db_graph=$1
./gbolt/gbolt $db_graph

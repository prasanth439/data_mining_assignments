db_graph=$1
./gBolt/gbolt $db_graph

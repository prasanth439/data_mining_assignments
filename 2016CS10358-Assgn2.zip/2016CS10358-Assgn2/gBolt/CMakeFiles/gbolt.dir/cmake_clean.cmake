file(REMOVE_RECURSE
  "CMakeFiles/gbolt.dir/src/history.cc.o"
  "CMakeFiles/gbolt.dir/src/database.cc.o"
  "CMakeFiles/gbolt.dir/src/output.cc.o"
  "CMakeFiles/gbolt.dir/src/gbolt.cc.o"
  "CMakeFiles/gbolt.dir/src/main.cc.o"
  "CMakeFiles/gbolt.dir/src/matching.cc.o"
  "CMakeFiles/gbolt.dir/src/gbolt_count.cc.o"
  "CMakeFiles/gbolt.dir/src/gbolt_execute.cc.o"
  "CMakeFiles/gbolt.dir/src/gbolt_extend.cc.o"
  "CMakeFiles/gbolt.dir/src/gbolt_mine.cc.o"
  "gbolt.pdb"
  "gbolt"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/gbolt.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

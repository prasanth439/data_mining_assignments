#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/vf2_sub_graph_iso.hpp>
#include<iostream>
#include<fstream>
using namespace boost;

void convertFileFormat(std::string inputpath, std::string outputpath);

int main(int argc,const char*argv[]) {

typedef property<edge_name_t, char> edge_property;
typedef property<vertex_name_t, char, property<vertex_index_t, int> > vertex_property;
typedef adjacency_list<vecS, vecS, bidirectionalS, vertex_property, edge_property> graph_type;
typedef property_map<graph_type, edge_name_t>::type edge_name_map_t;
typedef property_map_equivalent<edge_name_map_t, edge_name_map_t> edge_comp_t;
typedef property_map<graph_type, vertex_name_t>::type vertex_name_map_t;
typedef property_map_equivalent<vertex_name_map_t, vertex_name_map_t> vertex_comp_t;

  // Using a vecS graphs => the index maps are implicit.
  
  // Build graph1
  graph_type graph1;
  
  add_vertex(vertex_property('a'), graph1);
  add_vertex(vertex_property('a'), graph1);
  add_vertex(vertex_property('a'), graph1);
  
  add_edge(0, 1, edge_property('b'), graph1); 
  add_edge(0, 1, edge_property('b'), graph1); 
  add_edge(0, 1, edge_property('d'), graph1); 
  
  add_edge(1, 2, edge_property('s'), graph1); 
  
  add_edge(2, 2, edge_property('l'), graph1); 
  add_edge(2, 2, edge_property('l'), graph1); 
  
  // Build graph2
  graph_type graph2;
  
  add_vertex(vertex_property('a'), graph2);
  add_vertex(vertex_property('a'), graph2);
  add_vertex(vertex_property('a'), graph2);
  add_vertex(vertex_property('a'), graph2);
  add_vertex(vertex_property('a'), graph2);
  add_vertex(vertex_property('a'), graph2);
  
  add_edge(0, 1, edge_property('a'), graph2); 
  add_edge(0, 1, edge_property('a'), graph2); 
  add_edge(0, 1, edge_property('b'), graph2); 

  add_edge(1, 2, edge_property('s'), graph2); 
  
  add_edge(2, 3, edge_property('b'), graph2); 
  add_edge(2, 3, edge_property('d'), graph2); 
  add_edge(2, 3, edge_property('b'), graph2); 
  
  add_edge(3, 4, edge_property('s'), graph2); 
  
  add_edge(4, 4, edge_property('l'), graph2); 
  add_edge(4, 4, edge_property('l'), graph2); 

  add_edge(4, 5, edge_property('c'), graph2); 
  add_edge(4, 5, edge_property('c'), graph2); 
  add_edge(4, 5, edge_property('c'), graph2); 
  
  add_edge(5, 0, edge_property('s'), graph2); 
  
  // create predicates

  vertex_comp_t vertex_comp = make_property_map_equivalent(get(vertex_name, graph1), get(vertex_name, graph2));
  

  edge_comp_t edge_comp = make_property_map_equivalent(get(edge_name, graph1), get(edge_name, graph2));
 
  // Create callback
  vf2_print_callback<graph_type, graph_type> callback(graph1, graph2);

  vf2_subgraph_iso(graph1, graph2, callback, vertex_order_by_mult(graph1),edges_equivalent(edge_comp).vertices_equivalent(vertex_comp));


  
    std::vector<int> list1;
    // size_t n, m;
    // std::cin >> n >> m; 
    std::string in_file,out_file;
    std::ofstream ofle;
    //String path = "C:\\temp\\datafile.txt"; 
    if (argc==3){
        in_file = argv[1];
        out_file = argv[2];
        ofle.open(out_file,std::ios::app);
    }
    else{
        std::cerr<<"Insufficient or More arguments\n";
    }
    convertFileFormat(in_file, out_file); 

    
    // bool graph[n][m], que[m];
    // for (int i = 0 ; i < n ; i++){
    //     for (int  j = 0; j < m ; j++){
    //     std::cin >> graph[i][j];
    //     }
    // }
    
    // for (int  i = 0; i < m ; i++){
    //     std::cin >> que[i];
    // }
 
    // for (int i = 0; i < n; i++){
    //     bool present = true;
    //     for (int j = 0; j < m ; j++){
    //         if (graph[i][j] != que[j] && que[j] == true)  {
    //             present = false;
    //             break;
    //         }
    //     }
    //     if (present) {
    //         list1.push_back(i);
    //     }
    // }
 
//  for (auto x : list1)
//     	std::cout << "Sub query graph matched with graph ID" << x << "\n";
    	
	ofle.close();
}


void convertFileFormat(std::string inputpath, std::string outputpath){

typedef property<edge_name_t, int> edge_property;
typedef property<vertex_name_t, int, property<vertex_index_t, int> > vertex_property;
typedef adjacency_list<vecS, vecS, bidirectionalS, vertex_property, edge_property> graph_type;
typedef property_map<graph_type, edge_name_t>::type edge_name_map_t;
typedef property_map_equivalent<edge_name_map_t, edge_name_map_t> edge_comp_t;
typedef property_map<graph_type, vertex_name_t>::type vertex_name_map_t;
typedef property_map_equivalent<vertex_name_map_t, vertex_name_map_t> vertex_comp_t;

    std::vector<graph_type> vect;
    std::string line = "";
    std::ifstream myfile;
    std::string prev_vertex = "";
 
    myfile.open(inputpath);
    if (myfile.is_open()) {

    do
    {

        if (line == "") {
            getline (myfile,line);
        } 
   	  	
        if ( line[0] == 't') { 

            int pos = line.find("#");
            // std::string graphid = line.substr(pos2);
            // No need to insert it in the vector as of now.
            graph_type graph;  
        
            while ( getline (myfile,line)) {

                if (line[0] == 'v'){
                    // Returns first token
                    char *token = strtok((char*)line.c_str(), " ");
                    token = strtok(NULL, " ");
                    token = strtok(NULL, " ");
                    // no need to convert the vertex to the integer
                    add_vertex(vertex_property(std::stoi(token)), graph);
                }

                else if (line[0] == 'e'){
                    char *token = strtok((char*)line.c_str(), " ");
                    std::string edge_start = strtok(NULL, " ");
                    std::string edge_end = strtok(NULL, " ");
                    std::string edge_label = strtok(NULL, " ");
            
                    add_edge(stoi(edge_start),stoi(edge_end), edge_property(std::stoi(edge_label)), graph);
                } else if (line[0] == 't' || line.compare("u")==0 ) {
                    vect.push_back(graph);
                    break;
                }
            }
        }
        if(line.compare("u")){
            break;
        }
   } while(true);
  		    
    myfile.close();

    graph_type graph1;
  
    // add_vertex(vertex_property(1), graph1);
    add_vertex(vertex_property(1), graph1);
    add_vertex(vertex_property(2), graph1);
    add_vertex(vertex_property(2), graph1);
    add_vertex(vertex_property(3), graph1);

    add_edge(0, 1, edge_property(1), graph1); 
    add_edge(1, 2, edge_property(1), graph1); 
    add_edge(0, 3, edge_property(1), graph1); 
    // add_edge(1, 4, edge_property(1), graph1); 
    
    // print vect 
    for (auto v:vect)
    {

        std::cout<< "came in for"<<std::endl;

        vertex_comp_t vertex_comp = make_property_map_equivalent(get(vertex_name, graph1), get(vertex_name, v));
  
        edge_comp_t edge_comp = make_property_map_equivalent(get(edge_name, graph1), get(edge_name, v));
  
        vf2_print_callback<graph_type, graph_type> callback(graph1, v);

        vf2_subgraph_iso(graph1, v, callback, vertex_order_by_mult(graph1),edges_equivalent(edge_comp).vertices_equivalent(vertex_comp));

    }

    std::cout << "ended"<<std::endl;
  
  } else {
   std::cout << "Unable to open file"; 
  }
  return ;
}
#include<gbolt_function.h>
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/vf2_sub_graph_iso.hpp>
#include<vector>
#include<matching.h>
template <typename Graph1,typename Graph2>
  struct cd2_call_back {
    cd2_call_back(const Graph1& graph1, const Graph2& graph2) 
      : graph1_(graph1), graph2_(graph2) {}
    
    template <typename CorrespondenceMap1To2,typename CorrespondenceMap2To1>
    bool operator()(CorrespondenceMap1To2 f, CorrespondenceMap2To1) const {
      return true;
    }
  private:
    const Graph1& graph1_;
    const Graph2& graph2_;
};
void matching(std::vector<std::vector<int>>& graph_vectors,std::vector<int>& query_vector,std::vector<int>& answer)
{
    for(int i=0;i<graph_vectors.size();i++){
        answer.push_back(i);
        for(int j=0;j<query_vector.size();j++)
        {
            if(query_vector[j]<=graph_vectors[i][j])
            {
                //run
            }
            else{
                answer.pop_back();
                break;
            }
        }
    }
    return ;
}


void convertGraphsIsoMorphism(std::vector<mGraph>& db_graphs,std::vector<graphine_type>& iso_graphs){

    for(int i=0;i<db_graphs.size();i++)
    {
        graphine_type temp_graph;  
        iso_graphs.push_back(temp_graph);
        graphine_type& alias_graph = iso_graphs[i];
        for(int j=0;j<db_graphs[i].vertex_list.size();j++)
        {
            add_vertex(vertex_properties(db_graphs[i].vertex_list[j].label), alias_graph);
        }
        for(int k=0;k<db_graphs[i].edge_list.size();k++)
        {
            add_edge(db_graphs[i].edge_list[k].vert1,db_graphs[i].edge_list[k].vert2,edge_properties((db_graphs[i].edge_list[k].label)), alias_graph);

            // add_edge(db_graphs[i].edge_list[k].vert2,db_graphs[i].edge_list[k].vert1,edge_properties((db_graphs[i].edge_list[k].label)), alias_graph);
        }
    }
  return ;
}

void brute_comparision(std::vector<graphine_type>& db_iso_graphs,graphine_type& query_iso_graph,std::vector<int>& answer)
{
    int ans;
    auto vertex_order = vertex_order_by_mult(query_iso_graph);
    for (int i=0;i<db_iso_graphs.size();i++)
    {
        auto& v = db_iso_graphs[i];
        if( (query_iso_graph.m_vertices.size()<=v.m_vertices.size()) && (query_iso_graph.m_edges.size() <= v.m_edges.size()) ){
            vertex_comp_t vertex_comp = make_property_map_equivalent(get(vertex_name, query_iso_graph), get(vertex_name, v));
            edge_comp_t edge_comp = make_property_map_equivalent(get(edge_name, query_iso_graph), get(edge_name, v));
            cd2_call_back<graphine_type, graphine_type> callback(query_iso_graph, v);
            ans = vf2_subgraph_mono(query_iso_graph, v, callback, vertex_order ,edges_equivalent(edge_comp).vertices_equivalent(vertex_comp));
            if(ans)
            {
                answer.push_back(i);
            }
        }
    }
}

void brute_comparision_feature(std::vector<graphine_type>& feature_iso_graph,graphine_type& query_iso_graph,std::vector<int>& answer)
{
    int ans;
    for (int i=0;i<feature_iso_graph.size();i++)
    {
        
        auto& v = feature_iso_graph[i];
        if((v.m_vertices.size()<=query_iso_graph.m_vertices.size()) && (v.m_edges.size() <= query_iso_graph.m_edges.size()) ){
            vertex_comp_t vertex_comp = make_property_map_equivalent(get(vertex_name, v), get(vertex_name, query_iso_graph));
            edge_comp_t edge_comp = make_property_map_equivalent(get(edge_name, v), get(edge_name, query_iso_graph));

            cd2_call_back<graphine_type, graphine_type> callback(v, query_iso_graph);
            ans = vf2_subgraph_mono(v, query_iso_graph, callback, vertex_order_by_mult(v),edges_equivalent(edge_comp).vertices_equivalent(vertex_comp));
        
            if(ans)
            {
                answer.push_back(i);
            }
        }
    }
}

void brute_comparision(std::vector<graphine_type>& db_iso_graphs,graphine_type& query_iso_graph,std::vector<int>& answer, std::vector<int>& selected_list )
{
    int ans;
    auto vertex_order = vertex_order_by_mult(query_iso_graph);
    for (int i=0;i<selected_list.size();i++)
    {
        auto& v = db_iso_graphs[selected_list[i]];
        if( (query_iso_graph.m_vertices.size()<=v.m_vertices.size()) && (query_iso_graph.m_edges.size() <= v.m_edges.size()) ){
            vertex_comp_t vertex_comp = make_property_map_equivalent(get(vertex_name, query_iso_graph), get(vertex_name, v));
            edge_comp_t edge_comp = make_property_map_equivalent(get(edge_name, query_iso_graph), get(edge_name, v));
            cd2_call_back<graphine_type, graphine_type> callback(query_iso_graph, v);
            ans = vf2_subgraph_mono(query_iso_graph, v, callback, vertex_order,edges_equivalent(edge_comp).vertices_equivalent(vertex_comp));
            if(ans)
            {
                answer.push_back(selected_list[i]);
            }
        }
    }
}
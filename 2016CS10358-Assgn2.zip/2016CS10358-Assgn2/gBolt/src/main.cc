#include<iostream>
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/vf2_sub_graph_iso.hpp>
#include<matching.h>
#include<gbolt_function.h>
#include<gbolt.h>
typedef long long ll; // defined a shortform for long int as ll
// argv[1]   input_filename
// argv[2] for output_filename
// using namespace gbolt;
extern std::vector<std::vector<int>> feature_vectors;
extern std::vector<mGraph> feature_graphs;
std::unordered_map<std::string,ll> vertex_labels; // for mapping the input labels to integer
std::unordered_map<ll,ll> edge_labels;

void parse_input(FILE* inp_file,std::vector<mGraph>& db_graphs,std::vector<ll>& graph_id_mapping)
{
    ll  id,nvert,nedge,i,a1,a2;
    ll counter = 0,a3;
    std::string temp;
    ll graph_id = -1;

    while(fscanf(inp_file,"#%lld\n%lld\n",&id,&nvert)!=EOF){
        
        graph_id++; // graph id
        graph_id_mapping.push_back(id);
        db_graphs.push_back(mGraph());
        for(i=0;i<nvert;i++) // reading the vertices with labels 
        {                    // storing the labels in map with unique integer 
                             // and printing the vertex number and label in required format
            char temp2[100];
            fscanf(inp_file,"%100s\n",temp2);
            temp = std::string(temp2);
            if(vertex_labels.find(temp)==vertex_labels.end())
            {
                vertex_labels[temp] = counter++;
            }
            db_graphs[graph_id].vertex_list.push_back(mVert(vertex_labels[temp]));
        }
        fscanf(inp_file,"%lld",&nedge); // reading the edge count
        for(i=0;i<nedge;i++)
        {
            fscanf(inp_file,"%lld %lld %lld\n",&a1,&a2,&a3); // reading the three numbers and 
            if(edge_labels.find(a3)==edge_labels.end())
            {
            	edge_labels[a3] = counter++;
            }
            db_graphs[graph_id].edge_list.push_back(mEdge(a1,a2,a3));
        }
        fscanf(inp_file,"\n");
    }
    fclose(inp_file);
    return ;
}


int main_version1(int argc, const char*argv[])
{

    FILE * inp_file = nullptr; // input scanner
    FILE * out_file = nullptr; // output scanner
    inp_file = fopen(argv[1],"r"); 
    out_file = fopen(argv[2],"w");
    ll  id,nvert,nedge,i,a1,a2;
    ll counter = 0,a3;
    std::unordered_map<std::string,ll> vertex_labels; // for mapping the input labels to integer
    std::unordered_map<ll,ll> edge_labels;
    std::vector<ll> db_graph_id_mapping,query_graph_id_mapping;
    std::string temp;
    ll graph_id = -1;
    std::vector<mGraph> db_graphs,query_graphs;
    while(fscanf(inp_file,"#%lld\n%lld\n",&id,&nvert)!=EOF){
        
        graph_id++; // graph id
        db_graph_id_mapping.push_back(id);
        db_graphs.push_back(mGraph());
        fprintf(out_file,"t # %lld\n",graph_id); // printing the graph id in required format
        for(i=0;i<nvert;i++) // reading the vertices with labels 
        {                    // storing the labels in map with unique integer 
                             // and printing the vertex number and label in required format
            char temp2[100];
            fscanf(inp_file,"%100s\n",temp2);
            temp = std::string(temp2);
            if(vertex_labels.find(temp)==vertex_labels.end())
            {
                vertex_labels[temp] = counter++;
            }
            db_graphs[graph_id].vertex_list.push_back(mVert(vertex_labels[temp]));
            fprintf(out_file,"v %lld %lld\n",i,vertex_labels[temp]);
        }
        fscanf(inp_file,"%lld",&nedge); // reading the edge count
        for(i=0;i<nedge;i++)
        {
            fscanf(inp_file,"%lld %lld %lld\n",&a1,&a2,&a3); // reading the three numbers and 
            if(edge_labels.find(a3)==edge_labels.end())
            {
            	edge_labels[a3] = counter++;
            }
            db_graphs[graph_id].edge_list.push_back(mEdge(a1,a2,a3));
            fprintf(out_file,"e %lld %lld %lld\n",a1,a2,a3); // printing the same as they are in same format 
        }
        fscanf(inp_file,"\n");
    }
    fclose(inp_file);
    fclose(out_file);

    double support = 0.5;
    std::string output_file = argv[2];
    // callee_function(output_file,support);

    std::cout<<"Indexing Complete\n"<<std::endl;
    std::string query_graph,query_output_file;
    std::cin>>query_graph>>query_output_file;

    return 0;
}
void brute_force_method(FILE* outp_file,std::vector<mGraph>& db_graphs,std::vector<mGraph>& query_graphs,std::vector<ll>& db_graph_id_mapping)
{

    std::vector<graphine_type> db_iso_graphs,query_iso_graphs;
    convertGraphsIsoMorphism(db_graphs,db_iso_graphs);
    convertGraphsIsoMorphism(query_graphs,query_iso_graphs);
    for(auto& qisograph:query_iso_graphs)
    {
        std::vector<int> answer;
        brute_comparision(db_iso_graphs,qisograph,answer);
        for(auto x:answer)
        {
            fprintf(outp_file,"%lld ",db_graph_id_mapping[x]);
        }
        fprintf(outp_file,"\n");
    }
};
int main(int argc,const char*argv[])
{
    std::ios::sync_with_stdio(false);
    FILE * db_graph_file = nullptr; // input scanner
    db_graph_file = fopen(argv[1],"r"); 
    std::vector<ll> db_graph_id_mapping,query_graph_id_mapping;
    std::string temp;
    ll graph_id = -1;
    std::vector<mGraph> db_graphs,query_graphs;
    parse_input(db_graph_file,db_graphs,db_graph_id_mapping);
    double support = 0.5;
    std::vector<graphine_type> db_iso_graphs;
    convertGraphsIsoMorphism(db_graphs,db_iso_graphs); // already converted db graphs
    std::cout<<"Indexing Complete"<<std::endl;
    std::string query_graph,query_output_file;
    std::cin>>query_graph>>query_output_file;
    FILE* query_graph_file = fopen(query_graph.c_str(),"r");
    parse_input(query_graph_file,query_graphs,query_graph_id_mapping);
    FILE * query_write_file = fopen(query_output_file.c_str(),"w");
    callee_function("",0.2,db_graphs,db_graph_id_mapping);
    // FILE * debug_file = fopen("debug_file","w");
    // fprintf(debug_file," feature_graphs\n");
    // for(auto &b:feature_graphs)
    // {
    //     fprintf(debug_file," feature_graph i\n");
    //     int count = 0;
    //     for(auto c:b.vertex_list)
    //     {
    //         fprintf(debug_file,"%d %d \n",count,c.label);
    //         // std::cout<<count<<" "<<c.label<<std::endl;
    //         count++;
    //     }
    //     count = 0;
    //     for(auto c:b.edge_list)
    //     {
    //         fprintf(debug_file,"%d %d %d\n",c.vert1,c.vert2,c.label);
    //         // std::cout<<c.vert1<<" "<<c.vert2<<" "<<c.label<<std::endl;
    //         // count++; 
    //     }
    // }
    
    // fprintf(debug_file," feature_vectors\n");
    // for(int i=0;i<feature_vectors.size();i++)
    // {
    //     fprintf(debug_file,"%d :",i);
    //     for(int j=0;j<feature_vectors[i].size();j++)
    //         fprintf(debug_file,"%d ",feature_vectors[i][j]);

    //     fprintf(debug_file,"\n");
    // }

    std::vector<graphine_type> feature_graph_iso_graphs;
    convertGraphsIsoMorphism(feature_graphs,feature_graph_iso_graphs); 
     
    // now convert the query graphs to iso graphs (convGraph)
    std::vector<graphine_type> query_iso_graphs;
    convertGraphsIsoMorphism(query_graphs,query_iso_graphs); 
     
    // now get feature vectors of query graph
    std::vector<std::vector<int>> feature_vectors_query;
    for (auto&q:query_iso_graphs)
    {
        std::vector<int> ans;
        brute_comparision_feature(feature_graph_iso_graphs,q,ans);    
        feature_vectors_query.push_back(std::vector<int>(feature_vectors[0].size(),0));  
        int siz = feature_vectors_query.size()-1;  
        for(auto c:ans)
        {
            feature_vectors_query[siz][c] = 1;
        }
    }

    // fprintf(debug_file," feature_vectors_query\n");
    // for(int i=0;i<feature_vectors_query.size();i++)
    // {
    //     fprintf(debug_file,"%d :",i);
    //     for(int j=0;j<feature_vectors_query[i].size();j++)
    //         fprintf(debug_file,"%d ",feature_vectors_query[i][j]);

    //     fprintf(debug_file,"\n");
    // }

    
    // we already have feature vectors for db_graphs
    // now prune the db_graphs for each query graph separately

    std::vector<std::vector<int>> candidates;

    for (auto &q:feature_vectors_query)
    {       
        std::vector<int> ans;
        matching(feature_vectors, q,ans);
        candidates.push_back(ans);
    }
    
    // now brute force iso morphism test for  this pruned graphs for further pruning (which is our answer)
    for (int i =0;i<query_iso_graphs.size();i++)
    {   
        std::vector<int> ans;
        brute_comparision(db_iso_graphs,query_iso_graphs[i],ans);

        // brute_comparision(db_iso_graphs,query_iso_graphs[i],ans,candidates[i]);
        for (int j = 0; j < ans.size(); j++)
        {
            fprintf(query_write_file,"%lld ",db_graph_id_mapping[ans[j]]);
        }
        fprintf(query_write_file,"\n");
    }
    
    // clean console (vf2 output)

    return 0;
}
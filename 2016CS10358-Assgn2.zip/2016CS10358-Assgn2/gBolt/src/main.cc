#include<iostream>
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/vf2_sub_graph_iso.hpp>
#include<matching.h>
#include<gbolt_function.h>
#include<gbolt.h>
typedef long long ll; // defined a shortform for long int as ll
// argv[1]   input_filename
// argv[2] for output_filename
// using namespace gbolt;
extern std::vector<std::vector<int>> feature_vectors;
extern std::vector<mGraph> feature_graphs;
extern int global_db_size;
std::unordered_map<std::string,ll> vertex_labels; // for mapping the input labels to integer
std::unordered_map<ll,ll> edge_labels;

void parse_input(FILE* inp_file,std::vector<mGraph>& db_graphs,std::vector<ll>& graph_id_mapping)
{
    ll  id,nvert,nedge,i,a1,a2;
    ll counter = 0,a3;
    std::string temp;
    ll graph_id = -1;

    while(fscanf(inp_file,"#%lld\n%lld\n",&id,&nvert)!=EOF){
        
        graph_id++; // graph id
        graph_id_mapping.push_back(id);
        db_graphs.push_back(mGraph());
        for(i=0;i<nvert;i++) // reading the vertices with labels 
        {                    // storing the labels in map with unique integer 
                             // and printing the vertex number and label in required format
            char temp2[100];
            fscanf(inp_file,"%100s\n",temp2);
            temp = std::string(temp2);
            if(vertex_labels.find(temp)==vertex_labels.end())
            {
                vertex_labels[temp] = counter++;
            }
            db_graphs[graph_id].vertex_list.push_back(mVert(vertex_labels[temp]));
        }
        fscanf(inp_file,"%lld",&nedge); // reading the edge count
        for(i=0;i<nedge;i++)
        {
            fscanf(inp_file,"%lld %lld %lld\n",&a1,&a2,&a3); // reading the three numbers and 
            if(edge_labels.find(a3)==edge_labels.end())
            {
            	edge_labels[a3] = counter++;
            }
            db_graphs[graph_id].edge_list.push_back(mEdge(a1,a2,a3));
        }
        fscanf(inp_file,"\n");
    }
    fclose(inp_file);
    return ;
}



void brute_force_method(FILE* outp_file,std::vector<mGraph>& db_graphs,std::vector<mGraph>& query_graphs,std::vector<ll>& db_graph_id_mapping)
{

    std::vector<graphine_type> db_iso_graphs,query_iso_graphs;
    convertGraphsIsoMorphism(db_graphs,db_iso_graphs);
    convertGraphsIsoMorphism(query_graphs,query_iso_graphs);
    for(auto& qisograph:query_iso_graphs)
    {
        std::vector<int> answer;
        brute_comparision(db_iso_graphs,qisograph,answer);
        for(auto x:answer)
        {
            fprintf(outp_file,"%lld ",db_graph_id_mapping[x]);
        }
        fprintf(outp_file,"\n");
    }
};
void print_graph(std::vector<graphine_type> graph_p){

    for(auto &b:graph_p)
    {
        // fprintf(debug_file," feature_graph i\n");
        std::cout<<"for loop"<<std::endl; 
        int count = 0;
        for(auto c:b.m_edges)
        {
            
            // fprintf(debug_file,"%d %d \n",count,c.label);
            std::cout<<c.m_source<<" "<< c.m_target<<" "<<c.m_property.m_value<<std::endl;
            count++;
        }
        // count = 0;
        // for(auto c:b.edge_list)
        // {
        //     fprintf(debug_file,"%d %d %d\n",c.vert1,c.vert2,c.label);
        //     // std::cout<<c.vert1<<" "<<c.vert2<<" "<<c.label<<std::endl;
        //     // count++; 
        // }
    }

}
int main(int argc,const char*argv[])
{
    std::ios::sync_with_stdio(false);
    FILE * db_graph_file = nullptr; // input scanner
    db_graph_file = fopen(argv[1],"r"); 
    std::vector<ll> db_graph_id_mapping,query_graph_id_mapping;
    std::string temp;
    ll graph_id = -1;
    std::vector<mGraph> db_graphs,query_graphs;
    parse_input(db_graph_file,db_graphs,db_graph_id_mapping);
    global_db_size = db_graphs.size();
    double support = 0.5;
    std::vector<graphine_type> db_iso_graphs;
    convertGraphsIsoMorphism(db_graphs,db_iso_graphs); // already converted db graphs
    // std::cout<<"db_iso "<<std::endl;
    // print_graph(db_iso_graphs);
    std::cout<<"Indexing Complete"<<std::endl;
    std::string query_graph,query_output_file;
    std::cin>>query_graph>>query_output_file;
    FILE* query_graph_file = fopen(query_graph.c_str(),"r");
    parse_input(query_graph_file,query_graphs,query_graph_id_mapping);
    FILE * query_write_file = fopen(query_output_file.c_str(),"w");

    callee_function("",0.5,db_graphs,db_graph_id_mapping);

    // std::cout<<"feature_graphs "<< feature_graphs.size()<<std::endl; 

    // FILE * debug_file = fopen("debug_file","w");
    // fprintf(debug_file," feature_graphs\n");
    // for(auto &b:feature_graphs)
    // {
    //     fprintf(debug_file," feature_graph i\n");
    //     int count = 0;
    //     for(auto c:b.vertex_list)
    //     {
    //         fprintf(debug_file,"%d %d \n",count,c.label);
    //         // std::cout<<count<<" "<<c.label<<std::endl;
    //         count++;
    //     }
    //     count = 0;
    //     for(auto c:b.edge_list)
    //     {
    //         fprintf(debug_file,"%d %d %d\n",c.vert1,c.vert2,c.label);
    //         // std::cout<<c.vert1<<" "<<c.vert2<<" "<<c.label<<std::endl;
    //         // count++; 
    //     }
    // }
    
    // fprintf(debug_file," feature_vectors\n");
    // for(int i=0;i<feature_vectors.size();i++)
    // {
    //     fprintf(debug_file,"%d :",i);
    //     for(int j=0;j<feature_vectors[i].size();j++)
    //         fprintf(debug_file,"%d ",feature_vectors[i][j]);

    //     fprintf(debug_file,"\n");
    // }

    std::vector<graphine_type> feature_graph_iso_graphs;
    convertGraphsIsoMorphism(feature_graphs,feature_graph_iso_graphs); 
    //  std::cout<<"f_g_iso completed"<<std::endl; 
    //  print_graph(feature_graph_iso_graphs);
    // now convert the query graphs to iso graphs (convGraph)
    std::vector<graphine_type> query_iso_graphs;
    convertGraphsIsoMorphism(query_graphs,query_iso_graphs); 

    // std::cout<<"q_iso completed"<<std::endl;     
    //  print_graph(query_iso_graphs);

    // now get feature vectors of query graph
    std::vector<std::vector<int>> feature_vectors_query;
    // std::vector<VertexOrderSmall>  vertex_order_small;
    for (auto&q:query_iso_graphs)
    {
        std::vector<int> ans;
        brute_comparision_feature(feature_graph_iso_graphs,q,ans);    
        feature_vectors_query.push_back(std::vector<int>(feature_vectors[0].size(),0));  
        int siz = feature_vectors_query.size()-1;  
        for(auto c:ans)
        {
            feature_vectors_query[siz][c] = 1;
        }
    }

    // std::cout<<"feature_vec_query completed"<<std::endl;
    // fprintf(debug_file," feature_vectors_query\n");
    // for(int i=0;i<feature_vectors_query.size();i++)
    // {
    //     fprintf(debug_file,"%d :",i);
    //     for(int j=0;j<feature_vectors_query[i].size();j++)
    //         fprintf(debug_file,"%d ",feature_vectors_query[i][j]);

    //     fprintf(debug_file,"\n");
    // }

    
    // we already have feature vectors for db_graphs
    // now prune the db_graphs for each query graph separately

    std::vector<std::vector<int>> candidates;

    for (auto &q:feature_vectors_query)
    {       
        std::vector<int> ans;
        matching(feature_vectors, q,ans);

        // std::cout<<"ans "<<std::endl;
        // for (int i = 0; i < ans.size(); i++)
        // {
        //     std::cout<< ans[i]<<" "; 
        // }
        // std::cout<<std::endl;
        
        candidates.push_back(ans);

        // std::cout<<"cand_c "<< candidates[candidates.size()-1].size() <<std::endl;
    }

    int size_feature_vector = feature_vectors.size();

    // now brute force iso morphism test for  this pruned graphs for further pruning (which is our answer)
    for (int i =0;i<query_iso_graphs.size();i++)
    {   
        std::vector<int> ans;
        if(size_feature_vector==0){

            brute_comparision(db_iso_graphs,query_iso_graphs[i],ans);
        }
        else{

            brute_comparision(db_iso_graphs,query_iso_graphs[i],ans,candidates[i]);
        }

        for (int j = 0; j < ans.size(); j++)
        {
            fprintf(query_write_file,"%lld\t",db_graph_id_mapping[ans[j]]);
        }

        if(ans.size()==0){
            fprintf(query_write_file,"-1\t");
        }

        fprintf(query_write_file,"\n");
    }
    
    // clean console (vf2 output)

    return 0;
}
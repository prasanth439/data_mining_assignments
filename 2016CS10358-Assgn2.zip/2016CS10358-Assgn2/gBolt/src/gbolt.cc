#include<gbolt_function.h>
#include <gbolt.h>
#include <database.h>
#include <common.h>
#include <cxxopts.hpp>

// Initialize instance
using gbolt::Database;
Database *Database::instance_ = new Database();

int main_cache(int argc, char *argv[]) {
  
  cxxopts::Options options("gBolt", "very fast implementation for gSpan algorithm in data mining");
  options.add_options()
    ("i,input", "Input path of graph data", cxxopts::value<std::string>())
    ("o,output", "Output gbolt mining results", cxxopts::value<std::string>()->default_value(""))
    ("s,support", "Minimum subgraph frequency: (0.0, 1.0]", cxxopts::value<double>()->default_value("1.0"))
    ("m,mark", "Graph data separator", cxxopts::value<std::string>()->default_value(" "))
    ("p,parents", "Output subgraph parent ids",
     cxxopts::value<bool>()->default_value("false")->implicit_value("true"))
    ("d,dfs", "Output subgraph dfs patterns",
     cxxopts::value<bool>()->default_value("false")->implicit_value("true"))
    ("n,nodes", "Output frequent nodes",
     cxxopts::value<bool>()->default_value("false")->implicit_value("true"))
    ("h,help", "gBolt help");

  if (argc == 1) {
    LOG_INFO(options.help().c_str());
    return 0;
  }

  auto result = options.parse(argc, argv);

  if (result["help"].count() || result["h"].count()) {
    LOG_INFO(options.help().c_str());
    return 0;
  }

  std::string input = result["i"].count() ? result["i"].as<std::string>() : result["input"].as<std::string>();
  std::string output = result["o"].count() ? result["o"].as<std::string>() : result["output"].as<std::string>();
  double support = result["s"].count() ? result["s"].as<double>() : result["support"].as<double>();
  std::string mark = result["m"].count() ? result["m"].as<std::string>() : result["mark"].as<std::string>();
  bool parents = result["p"].count() ? result["p"].as<bool>() : result["parents"].as<bool>();
  bool dfs = result["d"].count() ? result["d"].as<bool>() : result["dfs"].as<bool>();
  bool nodes = result["n"].count() ? result["n"].as<bool>() : result["nodes"].as<bool>();

  if (support > 1.0 || support <= 0.0) {
    LOG_ERROR("Support value should be less than 1.0 and greater than 0.0");
  }
  // Read input

  Database::get_instance()->read_input(input, mark);
  // Construct algorithm
  gbolt::GBolt gbolt(output, support);
  gbolt.execute();
  // Save results
  if (output.size() != 0) {
    gbolt.save(parents, dfs, nodes);
  }
  return 0;
}


int callee_function(std::string input,
            double support,std::vector<mGraph>& db_graphs,std::vector<ll>& db_graph_id_mapping)
{
  std::string mark = " ";
  std::string output = "";
  bool parents = false;
  bool dfs = true;
  bool nodes = false;
  Database::get_instance()->note_db_mappings(db_graphs,db_graph_id_mapping);
  // Database::get_instance()->read_input(input, mark);
  gbolt::GBolt gbolt(output, support);
  
  gbolt.execute();

  if (output.size() != 0) {
    gbolt.save(parents, dfs, nodes);
  }
  return 0;
}
#ifndef MATCHING_H
#define MATCHING_H
#include<vector>
#include<gbolt_function.h>
using namespace boost;
typedef property<edge_name_t, int> edge_properties;
typedef property<vertex_name_t, int, property<vertex_index_t, int> > vertex_properties;
typedef adjacency_list<vecS, vecS, undirectedS, property<vertex_name_t, int, property<vertex_index_t, int> >, property<edge_name_t, int>> graphine_type;
typedef property_map<graphine_type, edge_name_t>::type edge_name_map_t;
typedef property_map_equivalent<edge_name_map_t, edge_name_map_t> edge_comp_t;
typedef property_map<graphine_type, vertex_name_t>::type vertex_name_map_t;
typedef property_map_equivalent<vertex_name_map_t, vertex_name_map_t> vertex_comp_t;
void matching(std::vector<std::vector<int>>& graph_vectors,std::vector<int>& query_vector,std::vector<int>& answer);
void brute_comparision(std::vector<graphine_type>& db_iso_graphs,graphine_type& query_iso_graph,std::vector<int>& answer);
void convertGraphsIsoMorphism(std::vector<mGraph>& db_graphs,std::vector<graphine_type>& iso_graphs);
void brute_comparision_feature(std::vector<graphine_type>& feature_iso_graphs,graphine_type& query_iso_graph,std::vector<int>& answer);
void brute_comparision(std::vector<graphine_type>& db_iso_graphs,graphine_type& query_iso_graph,std::vector<int>& answer, std::vector<int>& selected_list);
#endif
#ifndef GBOLT_FUNCTION_H
#define GBOLT_FUNCTION_H
#include<common.h>
typedef long long ll;
class mVert{
    public:
        int label;
        mVert(int l):label(l){};
};
class mEdge{
    public:
        int vert1,vert2;
        int label;
        mEdge(int v1,int v2,int lab):vert1(v1),vert2(v2),label(lab){};
};
class mGraph{
    public:
        std::vector<mVert> vertex_list;
        std::vector<mEdge> edge_list;
        mGraph(){};
};
int callee_function(std::string input_file,
            double support,
            std::vector<mGraph>& db_graphs,
            std::vector<ll>& db_graph_id_mapping);

#endif
#/bin/bash
input_file=$1
g++ -o conv_gspan gSpan_input.cpp
echo "Index"

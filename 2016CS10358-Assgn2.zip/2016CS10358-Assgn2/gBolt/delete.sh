rm -rf CMakeCache.txt cmake_install.cmake
make clean
cmake .
make


#include<cstdio>
#include<cstring>
#include<iostream>
#include<unordered_map>
typedef long long ll; // defined a shortform for long int as ll
using namespace std;
// argv[1] for input_filename
// argv[2] for output_filename
int main(int argc, const char*argv[])
{
    FILE * inp_file = nullptr; // input scanner
    FILE * out_file = nullptr; // output scanner
    inp_file = fopen(argv[1],"r"); 
    out_file = fopen(argv[2],"w");
    ll  id,nvert,nedge,i,a1,a2;
    ll counter = 0,a3;
    unordered_map<string,ll> mp; // for mapping the input labels to integer
    string temp;
    ll graph_id = -1;
    unordered_map<ll,ll> edge_labels;
    while(fscanf(inp_file,"#%lld\n%lld\n",&id,&nvert)!=EOF){
        
        graph_id++; // graph id
        fprintf(out_file,"t # %lld\n",graph_id); // printing the graph id in required format
        for(i=0;i<nvert;i++) // reading the vertices with labels 
        {                    // storing the labels in map with unique integer 
                             // and printing the vertex number and label in required format
            char temp2[100];
            fscanf(inp_file,"%100s\n",temp2);
            temp = string(temp2);
            if(mp.find(temp)==mp.end())
            {
                mp[temp] = counter++;
            }
            fprintf(out_file,"v %lld %lld\n",i,mp[temp]);
        }
        fscanf(inp_file,"%lld",&nedge); // reading the edge count
        for(i=0;i<nedge;i++)
        {
            fscanf(inp_file,"%lld %lld %lld\n",&a1,&a2,&a3); // reading the three numbers and 
            if(edge_labels.find(a3)==edge_labels.end())
            {
            	edge_labels[a3] = counter++;
            }
            fprintf(out_file,"e %lld %lld %lld\n",a1,a2,a3); // printing the same as they are in same format 
        }
        fscanf(inp_file,"\n");
    }
    fclose(inp_file);
    fclose(out_file);
    return 0;
}